# ci-curl
Check the original work at https://github.com/philsturgeon/codeigniter-curl
